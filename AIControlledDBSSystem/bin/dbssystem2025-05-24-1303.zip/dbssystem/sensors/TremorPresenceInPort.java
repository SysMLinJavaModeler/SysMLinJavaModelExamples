package dbssystem.sensors;

import java.util.Optional;
import dbssystem.common.TremorPresenceSignal;
import sysmlinjava.events.SysMLSignalEvent;
import sysmlinjava.items.SysMLSignal;
import sysmlinjava.parts.SysMLPart;
import sysmlinjava.ports.SysMLPort;

/**
 * Port for receiving the tremor presence indications from the tremor sensor by
 * the pulse sensor
 * 
 * @author ModelerOne
 *
 */
public class TremorPresenceInPort extends SysMLPort
{
	public TremorPresenceInPort(SysMLPart contextBlock, Long id, String name)
	{
		super(contextBlock, Optional.of(contextBlock), id, name);
	}

	@Override
	protected SysMLSignalEvent eventFor(SysMLSignal signal)
	{
		SysMLSignalEvent result = null;
		if (signal instanceof TremorPresenceSignal)
			result = new SysMLSignalEvent((TremorPresenceSignal)signal, "TremorPresenceEvent", 0L);
		return result;
	}

}
