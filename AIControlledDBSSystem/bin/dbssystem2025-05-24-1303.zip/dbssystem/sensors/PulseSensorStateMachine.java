package dbssystem.sensors;

import dbssystem.common.PressureSignalSignal;
import dbssystem.common.TremorPresenceSignal;
import sysmlinjava.events.SysMLSignalEvent;

/**
 * State machine for the PulseSensor. The state machine consists of only two
 * states - one to initialize the sensor and one to repeatedly handle receipts
 * of pressure signals from the patient as well as tremor presence signals from
 * the tremor sensor. Note this state machine extends a base state machine to
 * demonstrate the SysMLinJava's support for state machine reuse by
 * extension/sepcialization.
 * 
 * @author ModelerOne
 *
 */
public class PulseSensorStateMachine extends SensorStateMachine
{
	public PulseSensorStateMachine(PulseSensor contextBlock)
	{
		super(contextBlock, "PulseSensorStateMachine");
	}

	@Override
	protected void createEffectActionFunctions()
	{
		onSensedValueSignalEffectActivity = (event, contextBlock) ->
		{
			if (event.isPresent() && event.get() instanceof SysMLSignalEvent signalEvent)
				if (signalEvent.signal instanceof PressureSignalSignal pressureSignalSignal)
				{
					PulseSensor sensor = (PulseSensor)contextBlock.get();
					sensor.onPressureSignal(pressureSignalSignal.value);
				}
				else if (signalEvent.signal instanceof TremorPresenceSignal tremorPresenceSignal)
				{
					PulseSensor sensor = (PulseSensor)contextBlock.get();
					sensor.onTremorPresence(tremorPresenceSignal.isPresent);
				}
		};
	}

}
