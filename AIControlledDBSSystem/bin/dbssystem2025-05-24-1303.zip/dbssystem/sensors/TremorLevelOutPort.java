package dbssystem.sensors;

import dbssystem.common.TremorLevel;
import dbssystem.common.TremorLevelSignal;
import sysmlinjava.common.SysMLAnything;
import sysmlinjava.items.SysMLSignal;
import sysmlinjava.parts.SysMLPart;
import sysmlinjava.ports.SysMLPort;

/**
 * Port to transmit a tremor level out of the TremorSensor
 * 
 * @author ModelerOne
 *
 */
public class TremorLevelOutPort extends SysMLPort
{
	public TremorLevelOutPort(SysMLPart contextBlock, Long id, String name)
	{
		super(contextBlock, id, name);
	}

	@Override
	protected SysMLSignal signalFor(SysMLAnything object)
	{
		SysMLSignal result = null;
		if(object instanceof TremorLevel)
			result = new TremorLevelSignal((TremorLevel)object);
		return result;
	}
}
