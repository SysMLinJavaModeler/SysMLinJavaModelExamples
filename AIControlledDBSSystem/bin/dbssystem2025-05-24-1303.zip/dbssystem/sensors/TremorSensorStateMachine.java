
package dbssystem.sensors;

import java.util.Optional;
import dbssystem.common.MotionSignalSignal;
import sysmlinjava.events.SysMLSignalEvent;
import sysmlinjava.javaannotations.statemachines.Effect;
import sysmlinjava.javaannotations.statemachines.EffectActionFunction;
import sysmlinjava.javaannotations.statemachines.Guard;
import sysmlinjava.javaannotations.statemachines.GuardCondition;
import sysmlinjava.javaannotations.statemachines.State;
import sysmlinjava.javaannotations.statemachines.Transition;
import sysmlinjava.states.FinalTransition;
import sysmlinjava.states.InitialTransition;
import sysmlinjava.states.SysMLEffect;
import sysmlinjava.states.SysMLEffectActionFunction;
import sysmlinjava.states.SysMLGuard;
import sysmlinjava.states.SysMLGuardCondition;
import sysmlinjava.states.SysMLState;
import sysmlinjava.states.SysMLStateMachine;
import sysmlinjava.states.SysMLTransition;
import sysmlinjava.states.SysMLTransitionKind;

/**
 * State machine for the TremorSensor. The state machine consists of only two states
 * - one to initialize the sensor and one to repeatedly handle receipts of
 * motion signals from the patient.
 * 
 * @author ModelerOne
 *
 */
public class TremorSensorStateMachine extends SysMLStateMachine
{
	@State
	protected SysMLState initializingState;
	@State
	protected SysMLState operationalState;

	@Transition
	protected InitialTransition initialToInitializingTransition;
	@Transition
	protected SysMLTransition initializingToOperationalTransition;
	@Transition
	protected SysMLTransition operationalOnMotionSignalSignalTransition;
	@Transition
	protected SysMLTransition operationalToFinalTransition;

	@GuardCondition
	protected SysMLGuardCondition isMotionSignalGuardCondition;
	
	@Guard
	protected SysMLGuard isMotionSignalGuard;
	
	@EffectActionFunction
	protected SysMLEffectActionFunction onMotionSignalEffectActivity;

	@Effect
	protected SysMLEffect onMotionSignalEffect;

	public TremorSensorStateMachine(TremorSensor contextBlock)
	{
		super(Optional.of(contextBlock), true, "TremorSensorStateMachine");
	}

	@Override
	protected void createStates()
	{
		super.createStates();
		initializingState = new SysMLState(context, "Initializing");
		operationalState = new SysMLState(context, "Operational");
	}
	
	@Override
	protected void createGuardConditions()
	{
		isMotionSignalGuardCondition = (event, contextBlock) ->
		{
			return event.isPresent() &&
				event.get() instanceof SysMLSignalEvent signalEvent &&
				signalEvent.signal instanceof MotionSignalSignal;
		};
	}

	@Override
	protected void createGuards()
	{
		isMotionSignalGuard = new SysMLGuard(context, isMotionSignalGuardCondition, "isMotionSignal");
	}

	@Override
	protected void createEffectActionFunctions()
	{
		onMotionSignalEffectActivity = (event, contextBlock) ->
		{
			if(event.isPresent() &&
			   event.get() instanceof SysMLSignalEvent signalEvent &&
			   signalEvent.signal instanceof MotionSignalSignal motionSignalSignal)
			{
				TremorSensor sensor = (TremorSensor)contextBlock.get();
				sensor.onMotion(motionSignalSignal.value);
			}
		};
	}

	@Override
	protected void createEffects()
	{
		onMotionSignalEffect = new SysMLEffect(context, onMotionSignalEffectActivity, "onMotionSignal");
	}

	@Override
	protected void createTransitions()
	{
		initialToInitializingTransition = new InitialTransition(context, initialState, initializingState, "InitialToInitializing");
		initializingToOperationalTransition = new SysMLTransition(context, initializingState, operationalState, "InitializingToOperational");
		operationalOnMotionSignalSignalTransition = new SysMLTransition(context, operationalState, operationalState, Optional.of(SysMLSignalEvent.class), Optional.of(isMotionSignalGuard), Optional.of(onMotionSignalEffect), "OperationalOnMotionSignalSignal", SysMLTransitionKind.internal);
		operationalToFinalTransition = new FinalTransition(context, operationalState, finalState, "OperationalToFinal");
	}
}
