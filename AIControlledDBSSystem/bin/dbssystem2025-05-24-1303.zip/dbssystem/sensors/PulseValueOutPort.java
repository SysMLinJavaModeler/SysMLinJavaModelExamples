package dbssystem.sensors;

import dbssystem.common.PulseValue;
import dbssystem.common.PulseValueSignal;
import sysmlinjava.common.SysMLAnything;
import sysmlinjava.items.SysMLSignal;
import sysmlinjava.parts.SysMLPart;
import sysmlinjava.ports.SysMLPort;

/**
 * Port to transmit a pulse value out of the PulseSensor
 * 
 * @author ModelerOne
 *
 */
public class PulseValueOutPort extends SysMLPort
{
	public PulseValueOutPort(SysMLPart contextBlock, Long index, String name)
	{
		super(contextBlock, index, name);
	}

	@Override
	protected SysMLSignal signalFor(SysMLAnything object)
	{
		SysMLSignal result = null;
		if(object instanceof PulseValue)
			result = new PulseValueSignal((PulseValue)object);
		return result;
	}
}
