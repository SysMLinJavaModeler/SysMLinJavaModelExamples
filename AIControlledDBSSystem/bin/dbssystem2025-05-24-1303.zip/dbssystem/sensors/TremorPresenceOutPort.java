package dbssystem.sensors;

import dbssystem.common.TremorPresenceSignal;
import sysmlinjava.attributetypes.BBoolean;
import sysmlinjava.common.SysMLAnything;
import sysmlinjava.items.SysMLSignal;
import sysmlinjava.parts.SysMLPart;
import sysmlinjava.ports.SysMLPort;

/**
 * Port to transmit a tremor presence indicator out of the TremorSensor
 * 
 * @author ModelerOne
 *
 */
public class TremorPresenceOutPort extends SysMLPort
{
	public TremorPresenceOutPort(SysMLPart contextBlock, Long id, String name)
	{
		super(contextBlock, id, name);
	}

	@Override
	protected SysMLSignal signalFor(SysMLAnything object)
	{
		SysMLSignal result = null;
		if(object instanceof BBoolean)
			result = new TremorPresenceSignal((BBoolean)object);
		return result;
	}
}
