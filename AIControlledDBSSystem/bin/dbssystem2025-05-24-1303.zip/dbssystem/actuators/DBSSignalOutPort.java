package dbssystem.actuators;

import dbssystem.common.DBSSignal;
import dbssystem.common.DBSSignalSignal;
import sysmlinjava.common.SysMLAnything;
import sysmlinjava.items.SysMLSignal;
import sysmlinjava.ports.SysMLPort;

/**
 * Port to transmit a low-power signal out of the DBS actuator
 * 
 * @author ModelerOne
 *
 */
public class DBSSignalOutPort extends SysMLPort
{

	public DBSSignalOutPort(DBSActuator contextBlock)
	{
		super(contextBlock, 0L, "DBSSignalOutPort");
	}

	@Override
	protected SysMLSignal signalFor(SysMLAnything object)
	{
		SysMLSignal result = null;
		if(object instanceof DBSSignal)
			result = new DBSSignalSignal((DBSSignal)object);
		return result;
	}

}
