package dbssystem.patient;

import java.time.Duration;
import java.time.Instant;
import java.util.Optional;
import dbssystem.common.DBSSignal;
import dbssystem.common.MotionSignal;
import dbssystem.common.PressureSignal;
import sysmlinjava.attributetypes.FrequencyHertz;
import sysmlinjava.attributetypes.IInteger;
import sysmlinjava.attributetypes.JerkMetersPerSecondCubed;
import sysmlinjava.attributetypes.PhaseShiftRadians;
import sysmlinjava.attributetypes.PotentialElectricalVolts;
import sysmlinjava.javaannotations.actions.Calculation;
import sysmlinjava.javaannotations.actions.Action;
import sysmlinjava.javaannotations.attributes.Attribute;
import sysmlinjava.javaannotations.ports.Port;
import sysmlinjava.parts.SysMLPart;

/**
 * Patient is the SysMLinJava model of a patient using a deep-brain stimulation
 * system. It receives DBS signals from a DBS actuator emplanted in his brain to
 * reduce his tremor motion. The Patient also transmits tremor motion signals as
 * well as blood pressure signals to sensors that send information to a DBS
 * controller.
 * <p>
 * Note that this patient simulation model presents an "open loop" simulation,
 * i.e. the patient's response to the DBS is based solely on a time-based
 * calculation and is not a function of the received DBS signal. This simple
 * simulation is used to focus the simulation on demonstrating the concepts and
 * principles of modeling and simulation with SysMLinJava.
 * 
 * @author ModelerOne
 *
 */
public class Patient extends SysMLPart
{
	/**
	 * Port to receive the DBS signal from the DBS actuator
	 */
	@Port
	public DBSSignalInPort dbsSignalPort;
	/**
	 * Port to transmit a tremor motion signal to a tremor sensorr
	 */
	@Port
	public MotionSignalOutPort motionOutPort;
	/**
	 * Port to transmit a blood pressure signal to a pulse sensor
	 */
	@Port
	public PressureSignalOutPort pressureOutPort;

	/**
	 * Flow value of the current DBS signal input
	 */
	@Attribute
	public DBSSignal dbsSignalIn;
	/**
	 * Flow value of the current tremor motion signal output
	 */
	@Attribute
	public MotionSignal motionOut;
	/**
	 * Flow value of the current blood pressure signal output
	 */
	@Attribute
	public PressureSignal pressureOut;

	/**
	 * Value of time at which the patient simulation began
	 */
	@Attribute
	public Instant startInstant;

	/**
	 * Constructor
	 */
	public Patient()
	{
		super("Patient", 0L);
	}

	/**
	 * Event handler (reception) to receive the next value of the DBS signal
	 * 
	 * @param signal the DBS signal value
	 */
	@Action
	public void onDBSSignal(DBSSignal signal)
	{
		logger.info(signal.toString());
		dbsSignalIn.setValue(signal);
	}

	/**
	 * Event handler for the next time at which the simulation is to transmit
	 * patient tremor motion and blood pressure values to the sensors.
	 */
	@Action
	public void onMotionTime()
	{
		logger.info("motion time");
		calculateMotionPressureOut();
		motionOutPort.transmit(motionOut);
		pressureOutPort.transmit(pressureOut);
	}

	@Override
	public void start()
	{
		super.start();
		dbsSignalPort.start();
	}

	@Override
	public void stop()
	{
		dbsSignalPort.stop();
		super.stop();
	}

	/**
	 * Calculate the patient's new tremor motion and blood pressure
	 * values
	 */
	@Calculation
	private void calculateMotionPressureOut()
	{
		Duration timeSinceStart = Duration.between(startInstant, Instant.now());
		motionOut.jerk.value = 0.6 - (0.6 / 300.0) * timeSinceStart.toSeconds();
		pressureOut.rate.value = 40;
	}

	@Override
	protected void createStateMachine()
	{
		stateMachine = Optional.of(new PatientStateMachine(this));
	}

	@Override
	protected void createAttributes()
	{
		startInstant = Instant.now();
		dbsSignalIn = new DBSSignal(new FrequencyHertz(0), new PotentialElectricalVolts(0), new PhaseShiftRadians(0));
		motionOut = new MotionSignal(new JerkMetersPerSecondCubed(0));
		pressureOut = new PressureSignal(IInteger.of(60));
	}

	@Override
	protected void createPorts()
	{
		dbsSignalPort = new DBSSignalInPort(this);
		pressureOutPort = new PressureSignalOutPort(this);
		motionOutPort = new MotionSignalOutPort(this);
	}
}
