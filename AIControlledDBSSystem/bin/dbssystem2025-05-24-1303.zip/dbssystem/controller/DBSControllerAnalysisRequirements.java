package dbssystem.controller;

import java.util.List;
import java.util.Optional;

import sysmlinjava.annotations.SysMLDocumentation;
import sysmlinjava.javaannotations.annotations.Documentation;
import sysmlinjava.javaannotations.requirements.Requirement;
import sysmlinjava.requirements.RequirementCategoryEnum;
import sysmlinjava.requirements.SysMLRequirement;
import sysmlinjava.requirements.SysMLRequirementsCollection;
import sysmlinjava.requirements.SysMLVerificationMethodKind;

/**
 * Collection of requirements for the DBS System analysis.
 */
public class DBSControllerAnalysisRequirements extends SysMLRequirementsCollection
{
	/**
	 * Documentation of textual specification of constraint of
	 * {@code dbsControllernAnalysisObjective} requirement
	 */
	@Documentation
	public static SysMLDocumentation dbsControllernAnalysisObjectiveDoc = new SysMLDocumentation("Analysis shall simulate the controller use of the ANN for DBS");

	/**
	 * Requirement for objective of the DBS System analysis, i.e. simulate controller use of the DBS ANN
	 */
	@Requirement
	public static SysMLRequirement dbsControllerAnalysisObjective = new SysMLRequirement(
	"1",
	"DBS System Analysis",
	dbsControllernAnalysisObjectiveDoc,
	Optional.empty(),
	Optional.of(DBSController.class),
	List.of(),
	List.of(),
	List.of(),
	false,
	List.of(),
	RequirementCategoryEnum.System,
	List.of(),
	List.of(SysMLVerificationMethodKind.Analysis),
	List.of(),
	List.of());
	

	/**
	 * Documentation of textual specification of constraint of
	 * {@code swapAnalysisObjective} requirement
	 */
	@Documentation
	public static SysMLDocumentation swapcAnalysisObjectiveDoc = new SysMLDocumentation("Analysis shall calculate system size, weight, and power, cooling (SWAPC) sums");

	/**
	 * Requirement for objective of the SWAPC analysis, i.e. calculate system size, weight, power, cooling of the C4S2 system
	 */
	@Requirement
	public static SysMLRequirement swapcAnalysisObjective = new SysMLRequirement(
	"1",
	"C4S2 Execution Analysis",
	swapcAnalysisObjectiveDoc,
	Optional.empty(),
	Optional.of(DBSController.class),
	List.of(),
	List.of(),
	List.of(),
	false,
	List.of(),
	RequirementCategoryEnum.System,
	List.of(),
	List.of(SysMLVerificationMethodKind.Analysis),
	List.of(),
	List.of());

	static
	{
		validate(DBSControllerAnalysisRequirements.class);
		
		setComposedOfs();
	}

	protected static void setComposedOfs()
	{
		dbsControllerAnalysisObjective.composedOf = List.of();
	}
}
