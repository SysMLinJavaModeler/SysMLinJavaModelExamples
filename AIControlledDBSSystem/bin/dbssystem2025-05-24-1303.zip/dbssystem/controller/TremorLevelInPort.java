package dbssystem.controller;

import java.net.InetAddress;
import java.util.Optional;
import dbssystem.common.TremorLevelSignal;
import sysmlinjava.events.SysMLSignalEvent;
import sysmlinjava.items.SysMLSignal;
import sysmlinjava.ports.SysMLPort;

/**
 * Port to receive tremor level values from the tremor motion sensor by the
 * controller
 * 
 * @author ModelerOne
 *
 */
public class TremorLevelInPort extends SysMLPort
{
	/**
	 * Constructor
	 * 
	 * @param context   DBSController of which this is a port, receives signals
	 * @param ipAddress IP address to be used for UDP-based port receptions
	 * @param udpPort   UDP port number to be used for UDP-based port receptions
	 */
	public TremorLevelInPort(DBSController context, InetAddress ipAddress, Integer udpPort)
	{
		super(context, Optional.of(context), ipAddress, udpPort, 0L, "TremorLevelInPort");
	}

	@Override
	protected SysMLSignalEvent eventFor(SysMLSignal signal)
	{
		SysMLSignalEvent result = null;
		if (signal instanceof TremorLevelSignal)
			result = new SysMLSignalEvent((TremorLevelSignal)signal, "Tremor Level", 0L);
		return result;
	}

}
