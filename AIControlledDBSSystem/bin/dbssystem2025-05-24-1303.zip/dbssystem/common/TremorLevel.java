package dbssystem.common;

import java.io.Serializable;
import sysmlinjava.attributetypes.DistanceMillimeters;
import sysmlinjava.attributetypes.FrequencyHertz;
import sysmlinjava.attributetypes.SysMLAttributeType;
import sysmlinjava.javaannotations.attributes.Attribute;
import sysmlinjava.units.SysMLinJavaUnits;

public class TremorLevel extends SysMLAttributeType implements Serializable
{
	private static final long serialVersionUID = -44622084523635911L;

	@Attribute
	public FrequencyHertz frequency;
	@Attribute
	public DistanceMillimeters amplitude;
	
	public TremorLevel(FrequencyHertz frequency, DistanceMillimeters amplitude)
	{
		super();
		this.frequency = frequency;
		this.amplitude = amplitude;
	}

	public void setValue(TremorLevel level)
	{
		frequency.value = level.frequency.value;
		amplitude.value = level.amplitude.value;
		notifyAttributeObservers();
	}

	@Override
	public void createUnits()
	{
		units = SysMLinJavaUnits.Object;
	}

	@Override
	public String toString()
	{
		return String.format("TremorLevel [frequency=%s, amplitude=%s]", frequency, amplitude);
	}
}
