package dbssystem.common;

import java.io.Serializable;
import sysmlinjava.attributetypes.JerkMetersPerSecondCubed;
import sysmlinjava.common.SysMLAnything;
import sysmlinjava.javaannotations.attributes.Attribute;

public class MotionSignal extends SysMLAnything  implements Serializable
{
	private static final long serialVersionUID = 1851159395194130147L;

	@Attribute
	public JerkMetersPerSecondCubed jerk;

	public MotionSignal(JerkMetersPerSecondCubed value)
	{
		super();
		this.jerk = value;
	}

	@Override
	public String toString()
	{
		return String.format("MotionSignal [value=%s]", jerk);
	}
}
