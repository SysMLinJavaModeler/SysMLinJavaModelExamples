
package dbssystem.sensors;

import dbssystem.common.MotionSignalSignal;
import sysmlinjava.events.SysMLSignalEvent;
import sysmlinjava.javaannotations.statemachines.Effect;
import sysmlinjava.javaannotations.statemachines.EffectActionFunction;
import sysmlinjava.javaannotations.statemachines.Guard;
import sysmlinjava.javaannotations.statemachines.GuardCondition;
import sysmlinjava.javaannotations.statemachines.State;
import sysmlinjava.javaannotations.statemachines.Transition;
import sysmlinjava.states.InitialTransition;
import sysmlinjava.states.SysMLEffect;
import sysmlinjava.states.SysMLEffectActionFunction;
import sysmlinjava.states.SysMLGuard;
import sysmlinjava.states.SysMLGuardCondition;
import sysmlinjava.states.SysMLState;
import sysmlinjava.states.SysMLTransition;

/**
 * State machine for the TremorSensor. The state machine consists of only two states
 * - one to initialize the sensor and one to repeatedly handle receipts of
 * motion signals from the patient.
 * 
 * @author ModelerOne
 *
 */
public class TremorSensorStateMachine extends SensorStateMachine
{
	@State
	protected SysMLState initializingState;
	@State
	protected SysMLState operationalState;

	@Transition
	protected InitialTransition initialToInitializingTransition;
	@Transition
	protected SysMLTransition initializingToOperationalTransition;
	@Transition
	protected SysMLTransition operationalOnMotionSignalSignalTransition;
	@Transition
	protected SysMLTransition operationalToFinalTransition;

	@GuardCondition
	protected SysMLGuardCondition isMotionSignalGuardCondition;
	
	@Guard
	protected SysMLGuard isMotionSignalGuard;
	
	@EffectActionFunction
	protected SysMLEffectActionFunction onMotionSignalEffectActivity;

	@Effect
	protected SysMLEffect onMotionSignalEffect;

	public TremorSensorStateMachine(TremorSensor contextSensor)
	{
		super(contextSensor, "TremorSensorStateMachine");
	}

	@Override
	protected void createGuardConditions()
	{
		isSensedValueGuardCondition = (event, contextSensor) ->
		{
			return contextSensor.isPresent() &&
			contextSensor.get() instanceof TremorSensor &&
			event.isPresent() &&
			event.get() instanceof SysMLSignalEvent signalEvent &&
			(signalEvent.signal instanceof MotionSignalSignal);

		};
	}

	@Override
	protected void createEffectActionFunctions()
	{
		onSensedValueSignalEffectActivity = (event, contextSensor) ->
		{
			if (event.isPresent())
			{
				if (contextSensor.isPresent() && contextSensor.get() instanceof TremorSensor sensor)
				{
					if (event.get() instanceof SysMLSignalEvent signalEvent)
					{
						if (signalEvent.signal instanceof MotionSignalSignal motionSignalSignal)
							sensor.onMotion(motionSignalSignal.value);
					}
					else
						logger.warning("unrecognized signal event: " + event.get().getClass().getSimpleName() + ", i.e. not a SysMLSignalEvent");
				}
				else
					logger.warning("missing TremorSensor context");
			}
			else
				logger.warning("missing sensed value signal event");
		};
	}
}
