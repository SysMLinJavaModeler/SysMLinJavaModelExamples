
package dbssystem.sensors;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import dbssystem.controller.DBSController;
import sysmlinjava.connectors.SysMLCrossContainerFlowConnector;
import sysmlinjava.connectors.SysMLCrossContainerFlowConnectorFunction;
import sysmlinjava.connectors.SysMLFlowConnector;
import sysmlinjava.connectors.SysMLFlowConnectorFunction;
import sysmlinjava.javaannotations.connectors.CrossContainerFlowConnector;
import sysmlinjava.javaannotations.connectors.CrossContainerFlowConnectorFunction;
import sysmlinjava.javaannotations.connectors.FlowConnector;
import sysmlinjava.javaannotations.connectors.FlowConnectorFunction;
import sysmlinjava.javaannotations.parts.ExternalPartReplica;
import sysmlinjava.javaannotations.parts.Part;
import sysmlinjava.parts.PartContainer;
import sysmlinjava.views.interactionssequencediagram.InteractionMessageSequenceDisplay;
import sysmlinjava.views.interactionssequencediagram.InteractionMessageTransmitter;
import sysmlinjava.views.interactionssequencediagram.InteractionMessageTransmitters;

/**
 * {@code DBSSensorsContainer} is the SysMLinJava model for a container of block
 * instances (parts) to execute in their own operating system process. The
 * container hosts the two patient sensors, i.e. a tremor motion sensor and a
 * blood pressure sensor. In accordance with the {@code PartContainer} construct, it
 * also contains a "replica" of the DBS controller to which it transmits the
 * sensor data. The replica of the DBS controller is used to create the
 * connectors from the sensors to the actual DBS controller, whose instance is
 * located in another {@code PartContainer}, i.e. in another operating system
 * process.
 * 
 * @author ModelerOne
 *
 */
public class DBSSensorsContainer extends PartContainer
{
	/**
	 * Part for the tremor motion sensor
	 */
	@Part
	public TremorSensor tremorSensor;
	/**
	 * Part for the pulse sensor
	 */
	@Part
	public PulseSensor pulseSensor;

	/**
	 * Replica part for DBS controller
	 */
	@ExternalPartReplica
	public DBSController dbsController;

	/**
	 * Function to make the connection of the tremor sensor to the pulse sensor for
	 * tremor presence indications
	 */
	@FlowConnectorFunction
	public SysMLFlowConnectorFunction tremorSensorToPulseSensorConnectorFunction;
	/**
	 * Connector to invoke the tremor-sensor-to-pulse-sesnor connector function
	 */
	@FlowConnector
	public SysMLFlowConnector tremorSensorToPulseSensorConnector;

	/**
	 * Function to make the connection of the tremor sensor to the DBS controller
	 * for sensor signals
	 */
	@CrossContainerFlowConnector
	public SysMLCrossContainerFlowConnector tremorSensorToControllerConnector;
	/**
	 * Function to make the connection of the pulse sensor to the DBS controller for
	 * sensor signals
	 */
	@CrossContainerFlowConnector
	public SysMLCrossContainerFlowConnector pulseSensorToControllerConnector;

	/**
	 * Connector to invoke the pulse-sensor-to-controller connector function
	 */
	@CrossContainerFlowConnectorFunction
	public SysMLCrossContainerFlowConnectorFunction pulseSensorToControllerConnectorFunction;
	/**
	 * Connector to invoke the tremor-sensor-to-controller connector function
	 */
	@CrossContainerFlowConnectorFunction
	public SysMLCrossContainerFlowConnectorFunction tremorSensorToControllerConnectorFunction;

	public DBSSensorsContainer()
	{
		super("DBSensorsContainer", 0L);
	}

	@Override
	protected void createExternalPartReplicas()
	{
		dbsController = new DBSController();
	}

	@Override
	protected void createParts()
	{
		tremorSensor = new TremorSensor();
		pulseSensor = new PulseSensor();
	}

	@Override
	protected void createFlowConnectorFunctions()
	{
		tremorSensorToPulseSensorConnectorFunction = () ->
		{
			tremorSensor.tremorPresencePort.connectToPeerPort(pulseSensor.tremorPresenceInPort);
		};
	}

	@Override
	protected void createFlowConnectors()
	{
		tremorSensorToPulseSensorConnector = new SysMLFlowConnector(tremorSensor, pulseSensor, tremorSensorToPulseSensorConnectorFunction);
	}

	@Override
	protected void createExternalConnectorFunctions()
	{
		tremorSensorToControllerConnectorFunction = () ->
		{
			tremorSensor.tremorLevelPort.connectToPeerPort(dbsController.tremorInPort);
		};
		pulseSensorToControllerConnectorFunction = () ->
		{
			pulseSensor.pulseOutPort.connectToPeerPort(dbsController.pulseInPort);
		};
	}

	@Override
	protected void createExternalConnectors()
	{
		tremorSensorToControllerConnector = new SysMLCrossContainerFlowConnector(tremorSensor, dbsController, tremorSensorToControllerConnectorFunction);
		pulseSensorToControllerConnector = new SysMLCrossContainerFlowConnector(pulseSensor, dbsController, pulseSensorToControllerConnectorFunction);
	}

	@Override
	public void enableInteractionMessageTransmissions()
	{
		InteractionMessageTransmitter transmitter = new InteractionMessageTransmitter(InteractionMessageSequenceDisplay.udpPort, true);
		InteractionMessageTransmitters interactionMessageTransmitters = new InteractionMessageTransmitters(transmitter, false);

		tremorSensor.tremorLevelPort.messageUtility = Optional.of(interactionMessageTransmitters);
		pulseSensor.pulseOutPort.messageUtility = Optional.of(interactionMessageTransmitters);
	}

	/**
	 * Main for the execution of the container in its own process
	 * 
	 * @param args null
	 */
	public static void main(String[] args)
	{
		DBSSensorsContainer container = new DBSSensorsContainer();
		container.tremorSensor.start();
		container.pulseSensor.start();
		try
		{
			Thread.sleep(300_000);
			container.tremorSensor.concurrentExecutionThreads.awaitTermination(30L, TimeUnit.NANOSECONDS);
			container.pulseSensor.concurrentExecutionThreads.awaitTermination(30L, TimeUnit.NANOSECONDS);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		container.tremorSensor.stop();
		container.pulseSensor.stop();
		System.exit(0);
	}
}
